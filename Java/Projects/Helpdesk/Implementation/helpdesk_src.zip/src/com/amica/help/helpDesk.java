package com.amica.help;

import com.sun.source.tree.Tree;

import java.util.*;

import static com.amica.help.Clock.getTime;
import static com.amica.help.Clock.format;

public class helpDesk implements HelpDeskAPI{
    ArrayList<Ticket> ticketList = new ArrayList<>();
    ArrayList<Technician> technicianList = new ArrayList<>();
    SortedSet<Synonym> synonymsList = new TreeSet<>();

    SortedSet<Tag> tagsList = new TreeSet<>();

    @Override
    public int createTicket(String originator, String description, Ticket.Priority priority) {
        //finds next available tech, creates a new ticket, adds note and assigns the tech
        Technician technician = getAvailableTechnician();
        int newTicketID = getLastTicketID() + 1;
        ticketList.add(new Ticket(newTicketID,originator,description,getTime(),priority));
        addNote (newTicketID,"Created ticket.");
        String techID = technician.getID();
        assignTechnician(newTicketID,techID);
        return newTicketID;
    }

    public int getLastTicketID() {
        //Return the size of Ticket ArrayList
        return ticketList.size();
    }

    public Technician getAvailableTechnician(){
        //Iterates through all technicians looking for the one that has the lowest assigned tickets. Req #5
        //Assume the first tech
        Technician availableTechnician = null;
        long lowestTicketCount = 999999999;
        for (Technician tech: technicianList) {
            if (tech.getActiveTicketCount() < lowestTicketCount) {
                availableTechnician = tech;
                lowestTicketCount = tech.getActiveTicketCount();
            }
        }
        //Technician availableTechnician = technicianList.get(0);
        //long lowestTicketCount = technicianList.get(0).activeTicketCount;
        //for (int i = 1; i < technicianList.size(); i++){
            //if (technicianList.get(i).getActiveTicketCount() < lowestTicketCount) {
                //availableTechnician = technicianList.get(i);
                //lowestTicketCount = technicianList.get(i).getActiveTicketCount();
            //}
        //}
        return availableTechnician;
    }

    @Override
    public void createTechnician(String technicianID, String name, long extension) {
        Technician newTechnician = new Technician (technicianID, name, extension, 0,0);
        technicianList.add(newTechnician);
    }
    public Technician getTechnicianByID (String techID) {
        Technician tech = technicianList.get(0);
        for (Technician i: technicianList) {
            if (i.getID().equals(techID)) {
                tech = i;
                break;
            }
        }
        return tech;
    }
    public void assignTechnician (int ticketID, String techID){
        Ticket ticket = getTicketByID(ticketID);
        ticket.setTechnicianID(techID);
        ticket.setStatus(Ticket.Status.ASSIGNED);
        Technician tech = getTechnicianByID(techID);
        tech.setActiveTicketCount(tech.getActiveTicketCount() + 1);
        addNote (ticketID,"ASSIGNED to Technician " + tech.getName() + " [" + tech.getID() + "]");
    }

    public void addNote(int ticketID, String note) {
        Ticket ticket = getTicketByID(ticketID);
        Events event = new Events(ticketID,getTime(),note);
        ticket.eventsList.add(event);
    }

    //@Override
    public void resolveTicket(int ticketID, String note) {
        Ticket ticket = getTicketByID(ticketID);
        Technician tech = getTechnicianByID(ticket.getTechnicianID());

        tech.setActiveTicketCount(tech.getActiveTicketCount() - 1);
        tech.setResolvedTicketCount(tech.getResolvedTicketCount() + 1);

        ticket.setStatus(Ticket.Status.RESOLVED);
        addNote (ticketID,"RESOLVED.");
        ticket.setResolved(getTime());
        ticket.setMinutesResolved((ticket.getResolved() - ticket.getCreated()) / 60000); //expressed in minutes
    }

    public void addTags(int ticketID, String... tags) {
        Ticket ticket = getTicketByID(ticketID);
        ticket.tagList.addAll(Arrays.asList(tags));
        addNote(ticketID, "Added tags " + Arrays.toString(tags));
    }

    public String getTag(String tag) {
        //Returns the defined tag synonym??
        //int index = synonymList.indexOf(tag);
        //if (index == -1) return ""; //TODO: should I return null instead?
        //else return synonymList.get(synonymList.indexOf(tag)).getSynonym();
        return null;
    }

    @Override
    public void addSynonym(String tag, String synonym) {
        Synonym pair = new Synonym(tag, synonym);
        //synonymsList.add(pair); this does not work: class com.amica.help.Synonym cannot be cast to class java.lang.Comparable (com.amica.help.Synonym is in unnamed module of loader 'app'; java.lang.Comparable is in module java.base of loader 'bootstrap')
    }

    //@Override
    public int reopenTicket(int priorTicketID, String reason, Ticket.Priority priority) {
        Ticket priorTicket = getTicketByID(priorTicketID);
        //We can't reopen an un-resolved ticket.
        if (priorTicket.getStatus() != Ticket.Status.RESOLVED) {
            return 0;
        }
        Technician technician = getAvailableTechnician();
        int newTicketID = getLastTicketID() + 1;
        Ticket newTicket =new Ticket(newTicketID,priorTicket.getOriginator(),priorTicket.getDescription(),getTime(),priority);
        ticketList.add(newTicket);
        //Copies all notes from previous ticket (Req. #19)
        newTicket.eventsList.addAll(new ArrayList<Events>(priorTicket.eventsList));
        addNote (newTicketID,"Ticket reopened from ticket #" + priorTicketID + ". Reason: " + reason);
        //Add the same tags
        newTicket.tagList.addAll(new ArrayList<String>(priorTicket.tagList));
        newTicket.setPriority(priority);
        assignTechnician(newTicketID,technician.getID());
        return newTicketID;
    }

    public Ticket getTicketByID(int ticketID) {
        if (ticketID > 0) {
            for (Ticket ticket : ticketList) {
                if (ticket.getID() == ticketID) {
                    return ticket;
                }
            }
        }
        return null;
    }

    @Override
    public SortedSet<Ticket> getTickets() {
        //TODO
        return null;
    }

    @Override
    public List<Ticket> getTicketsByStatus(Ticket.Status status) {
        ArrayList<Ticket> ticketListResult = new ArrayList<>();
        for (Ticket i: ticketList) {
            if (i.getStatus().equals(status)) {
                ticketListResult.add(i);
            }
        }
        return ticketListResult;
    }

    @Override
    public void listAllTickets() {
        for (Ticket i: ticketList) {
            printTicket (i);
        }
    }

    @Override
    public void printTicket(Ticket ticket) {
        System.out.println("Ticket  : " + ticket.getID());
        System.out.println("Descr.  : " + ticket.getDescription());
        System.out.println("Status  : " + ticket.getStatus());
        System.out.println("Priority: " + ticket.getPriority());
        System.out.println("Created : " + format(ticket.getCreated()));
        System.out.println("Resolved: " + format(ticket.getResolved()) + " (" + ticket.getMinutesResolved() + " mins.)");
        System.out.println("Tech    : " + ticket.getTechnicianID());
        System.out.println("Tags    : " + ticket.tagList);
        System.out.println("> Notes");
        //Prints Notes
        for (int n = 0; n < ticket.eventsList.size(); n++) {
            System.out.println(format(ticket.getEventsList().get(n).getTimestamp()) + ": " + ticket.getEventsList().get(n).getNote());
        }
        System.out.println();;
    }

    @Override
    public List<Ticket> getTicketsByNotStatus(Ticket.Status status) {
        ArrayList<Ticket> ticketListResult = new ArrayList<>();
        for (Ticket i: ticketList) {
            if (! i.getStatus().equals(status)) {
                ticketListResult.add(i);
            }
        }
        return ticketListResult;
    }

    @Override
    public List<Ticket> getTicketsByTechnician(String techID) {
        ArrayList<Ticket> ticketListResult = new ArrayList<>();
        for (Ticket i: ticketList) {
            if (i.getTechnicianID().equals(techID)) {
                ticketListResult.add(i);
            }
        }
        return ticketListResult;
    }

    @Override
    public List<Ticket> getTicketsWithAnyTag(String... tags) {
        ArrayList<Ticket> ticketListResult = new ArrayList<>();
        for (Ticket ticket: ticketList) {
            for (String ticketTag: ticket.tagList) {
                for (String tag: tags) {
                    String tag1 = tag.toLowerCase();
                    String tag2 =ticketTag.toLowerCase();
                    if (tag1.equals(tag2)) {
                        ticketListResult.add(ticket);
                    }
                }
            }
        }
        return ticketListResult;
    }

    @Override
    public int getAverageMinutesToResolve() {
        Map<String, Integer> hm = getAverageMinutesToResolvePerTechnician();
        int avgMinutes = 0;
        for (Map.Entry<String, Integer> set: hm.entrySet()) {
            avgMinutes = avgMinutes + set.getValue();
        }
        return avgMinutes / hm.size();
    }

    @Override
    public Map<String, Integer> getAverageMinutesToResolvePerTechnician() {
        Map<String, Integer> hm = new HashMap<>();
        //build map
        for (Technician tech: technicianList){
            if (tech.getResolvedTicketCount() > 0) {
                hm.put(tech.getID(), 0);
            }
        }
        //Sum all ticket resolve time (in minutes)
        for (Ticket ticket: ticketList) {
            //Sums all minutes resolved field for each technician
            if (ticket.getStatus() == Ticket.Status.RESOLVED) {
                hm.replace(ticket.getTechnicianID(), ticket.getMinutesResolved() + hm.get(ticket.getTechnicianID()));
            }
        }
        //Now calculates average
        //for (Technician tech: technicianList){
        for (Map.Entry<String, Integer> set: hm.entrySet()) {
            //Get tech's # of resolved tickets
            int ticketCount = 0;
            for (Technician tech: technicianList) {
                if (tech.getID() == set.getKey()) {
                    ticketCount = tech.getResolvedTicketCount();
                }
            }
            //Calculate avg time to resolve
            int sumTotalMinutesToResolve = hm.get(set.getKey());
            hm.replace(set.getKey(), sumTotalMinutesToResolve / ticketCount);
        }
        return hm;
    }

    @Override
    public List<Ticket> getTicketsByText(String text) {
        ArrayList<Ticket> ticketListResult = new ArrayList<>();
        for (Ticket t: ticketList) {
            boolean found = false;
            //Search in the ticket description
            if (t.getDescription().toLowerCase().contains(text.toLowerCase())) {
                found = true;
            } else {
                //Search in the notes
                //Events event = new Events(ticketID,getTime(),note);
                for (int i = 0; i < t.eventsList.size(); i++) {
                    if (t.eventsList.get(i).getNote().toLowerCase().contains(text.toLowerCase())) {
                        found = true;
                    }
                }
            }
            if (found) {
                ticketListResult.add(t);
            }
        }
        return ticketListResult;
    }
}
