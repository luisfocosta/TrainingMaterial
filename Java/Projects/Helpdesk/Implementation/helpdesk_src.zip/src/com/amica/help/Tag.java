package com.amica.help;

import java.util.ArrayList;

public class Tag {
    public String tag;
    public ArrayList<String> synonymsList = new ArrayList<>();
    //public ArrayList<String> prefCapitalization  = new ArrayList<>();
}
